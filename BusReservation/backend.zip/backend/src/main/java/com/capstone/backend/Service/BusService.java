package com.capstone.backend.Service;

import com.capstone.backend.Entity.Bus;

import java.util.List;

public interface BusService {
    List<Bus> getAllBuses();
}
