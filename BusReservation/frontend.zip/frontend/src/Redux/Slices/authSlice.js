// src/redux/slices/authSlice.js
import { createSlice} from '@reduxjs/toolkit';


const authSlice = createSlice({
  name: 'auth',
  initialState: {
    isAuthenticated: localStorage.getItem('token') !== null,
    token: localStorage.getItem("token") || null
  },
  reducers: {
    setAuthState: (state, action) => {
      const {isAuth,token} = action.payload;
      state.isAuthenticated = isAuth;
      state.token = token;
    },

  },
});


export const { setAuthState} = authSlice.actions;
export default authSlice.reducer;
