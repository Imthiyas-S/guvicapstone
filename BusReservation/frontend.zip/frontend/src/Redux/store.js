import { configureStore } from '@reduxjs/toolkit'
import auth from "./Slices/authSlice";

export const store = configureStore({
  reducer: {
    auth ,
  },
});