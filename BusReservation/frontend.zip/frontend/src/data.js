
  export const locations = [
    "Chennai",
    "Coimbatore",
    "Trichy",
    "Madurai",
    "Salem",
  ];
  