import React,{useState} from "react";
import "./Login.css";
import Axios from "../../api/Axios";
import { useDispatch } from "react-redux";
import {setAuthState} from "../../Redux/Slices/authSlice"
import { useNavigate } from "react-router";

const Login = () => {
  
    const [Data, setData] = useState({
        email: "",
        password: "",
      });
      const dispatch = useDispatch();
      const navigate = useNavigate();
    
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setData({
          ...Data,
          [name]: value,
        });
      };
    
      const handleSubmit = async (e) => {
        e.preventDefault();
        try {
          const response = await Axios.post("/api/v1/auth/authenticate", Data, {
            headers: { "Content-Type": "application/json" },
          });
          if(response?.data?.token){
           dispatch(setAuthState({isAuth:true,token:response?.data?.token})) 
           localStorage.setItem("token",response?.data?.token);
           navigate("/")
          }
        } catch (error) {
          console.error(error);
        }
      };

  return (
    <div className="login_wrapper">
         <form onSubmit={handleSubmit} className="register_form">
        <input
          type="email"
          name="email"
          id="email"
          value={Data.email}
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          id="password"
          value={Data.password}
          onChange={handleChange}
        />
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Login;
