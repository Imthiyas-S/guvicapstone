import React, { useState } from "react";
import "./Register.css";
import Axios from "../../api/Axios";
import { useDispatch } from "react-redux";
import {setAuthState} from "../../Redux/Slices/authSlice"
import { useNavigate } from "react-router";

const Register = () => {
  const [Data, setData] = useState({
    username: "",
    email: "",
    password: "",
    gender: "Male",
  });
  const dispatch = useDispatch();
  const navigate = useNavigate();


  const handleChange = (e) => {
    const { name, value } = e.target;
    setData({
      ...Data,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await Axios.post("/api/v1/auth/register", Data, {
        headers: { "Content-Type": "application/json" },
      });
      if(response?.data?.token){
       dispatch(setAuthState({isAuth:true,token:response?.data?.token})) 
       localStorage.setItem("token",response?.data?.token);
       navigate("/")
      }
    } catch (error) {
      console.error(error);
    }
  };
  return (
    <div className="register_wrapper">
      <form onSubmit={handleSubmit} className="register_form">
        <input
          type="text"
          name="username"
          id="username"
          value={Data.username}
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          id="email"
          value={Data.email}
          onChange={handleChange}
        />
        <input
          type="password"
          name="password"
          id="password"
          value={Data.password}
          onChange={handleChange}
        />
        <select
          name="gender"
          id="gender"
          value={Data.gender}
          onChange={handleChange}
        >
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Others">Others</option>
        </select>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Register;
