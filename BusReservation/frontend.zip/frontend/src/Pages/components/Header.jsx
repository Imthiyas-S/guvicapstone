import React from "react";
import styled from 'styled-components'
import { useNavigate } from "react-router";


const HeaderContainer = styled.header`
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: center;
    background-color: #007bff;
    color: white;
    text-align: center;
    padding: 1rem;
`;

const HeaderTitle = styled.h1`
    font-size: 2rem;
    margin:0
`


export default function Header(){


    const navigate = useNavigate();

    const handlelogout = () =>{
        localStorage.removeItem("token");
        localStorage.removeItem("Buses");
        navigate("/login");
    }
    return(
        <HeaderContainer>
            <HeaderTitle>Bus Ticket Booking App</HeaderTitle>

            <p style={{marginLeft:'auto', marginRight:'5vh',cursor:'pointer'}} onClick={() => handlelogout()}>Logout</p>
        </HeaderContainer>
    )
}