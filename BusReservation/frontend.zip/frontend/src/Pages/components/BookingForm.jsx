import React, { useState } from 'react'
import { Button, FormControl, FormGroup, FormLabel } from 'react-bootstrap'
import { useNavigate } from 'react-router'
import { locations } from '../../data'
import Axios from '../../api/Axios'

export default function BookingForm({ searchState,setSearchState, selectedSeats ,setSelectedSeats }) {
    const navigate = useNavigate()
    const [bookingIinfo, setboookinginfo] = useState([]);

    const handleInputChange = (seat, field, value) => {
        setboookinginfo(prevState => {
          const existingSeat = prevState.find(info => info.seat === seat);
          if (existingSeat) {
            return prevState.map(info =>
              info.seat === seat ? { ...info, [field]: value } : info
            );
          } else {
            return [...prevState, { seat, [field]: value }];
          }
        });
      };

      const handleBooking = async () =>{
        
        try {
          const response = await Axios.post("/save/booking",bookingIinfo,{headers: { "Content-Type": "application/json" }});
            if(response.status === 200){
                alert('Your ticket booked succesfully');
                setSearchState({
                    from: locations[0],
                    to: locations[3],
                    date: ''
                  })
                  setSelectedSeats([])
                navigate("/");
    
               }
            console.log(response);
        } catch (err) {
          console.error(err);
        }
      }
    

      console.log(bookingIinfo);
    return (
        <div className='text-center'>
            <h5>{searchState?.form} To{searchState?.to}</h5>
            <h5>Date: {searchState?.date}</h5>
            <br />
            <h5>Please fill below detials</h5>
            {selectedSeats?.map(seat => (
        <div key={seat}>
          <div className='my-3'>Seat No: {seat}</div>
          <FormGroup className='d-flex justify-content-center'>
            <FormLabel>Name:</FormLabel>
            <FormControl
              className='ms-2 mb-3 width-300'
              placeholder='Name'
              type='text'
              onChange={e => handleInputChange(seat, 'name', e.target.value)}
            />
          </FormGroup>
          <FormGroup className='d-flex justify-content-center'>
            <FormLabel>Age:</FormLabel>
            <FormControl
              className='ms-2 mb-3 width-300'
              placeholder='Age'
              type='number'
              onChange={e => handleInputChange(seat, 'age', e.target.value)}
            />
          </FormGroup>
        </div>
      ))}
           <Button onClick={() => handleBooking() } variant='success'>
            Pay Now

           </Button>

        </div>

    )
}
