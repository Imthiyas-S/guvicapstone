import "./App.css";
import Login from "./Pages/Login/Login";
import Register from "./Pages/Register/Register";
import BusSearch from "./Pages/Home/BusSearch";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import React, { useState } from "react";
import Header from "./Pages/components/Header";
import { locations } from "./data";
import BusLayout from "./Pages/components/BusLayout";
import BookingForm from "./Pages/components/BookingForm";

function App() {
  const [searchState, setSearchState] = useState({
    from: locations[0],
    to: locations[3],
    date: ''
  })

  const [selectedSeats, setSelectedSeats] = useState([]);
  
  return (
    <Router>
      <Header />
      <Routes>
        
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/"
          element={
            <BusSearch
            setSearchState={setSearchState}
            searchState={searchState}
            />
          }
        />
        <Route
         path="/bus/:id"
          element ={<BusLayout
             selectedSeats ={selectedSeats}
              setSelectedSeats = {setSelectedSeats}
             
              />
            }
            />
            <Route
         path="/bus/book"
          element ={<BookingForm
             selectedSeats ={selectedSeats}
              searchState = {searchState}
              setSelectedSeats = {setSelectedSeats}
              setSearchState = {setSearchState}
             
              />
            }
            />
      </Routes>
    </Router>
  );
}

export default App;
